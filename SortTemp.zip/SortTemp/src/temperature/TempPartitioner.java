package temperature;

import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;


public class TempPartitioner extends Partitioner<FloatWritable, Text> {
@Override
public int getPartition(FloatWritable key,Text values, int NumberofReducedTask)
{
	float temperature = key.get();
	if(NumberofReducedTask == 0)
	{
	return 0;
	}
	
	float MaxTemperature = 140, MinTemperature = 0;
	float partitions = (MaxTemperature-MinTemperature)/NumberofReducedTask;//250
	int returnValue = (int) Math.ceil(temperature/partitions);
	return (returnValue-1);
}
}
