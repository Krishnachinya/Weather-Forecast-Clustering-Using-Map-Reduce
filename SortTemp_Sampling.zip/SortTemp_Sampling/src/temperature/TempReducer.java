package temperature;

import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;

public class TempReducer extends Reducer<FloatWritable, Text, Text, FloatWritable> {
@Override
public void reduce(FloatWritable key,Iterable<Text> values, Context context)
{
	try {
	String year=null;
	for(Text val:values)
	{
		year = val.toString();
	}
	context.write(new Text(year),key);
	}catch (IOException | InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
