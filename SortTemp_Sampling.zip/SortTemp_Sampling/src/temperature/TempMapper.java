package temperature;

import java.io.*;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;


public class TempMapper extends Mapper<LongWritable,Text,FloatWritable,Text > {
	private String year;
	private float temperature;
	private String[] columns;
	@Override
	public void map(LongWritable key, Text value,Context context)
	{
		try {
		String line = value.toString();
		columns = line.toString().split("\\s{1,}|,\\s{0,}");
		if(!columns[0].contains("STN"))
		{
			year = columns[2];
			temperature = Float.parseFloat(columns[3]);
		//year = line.substring(15,26);
		//temperature = Float.parseFloat(line.substring(27,35));
		
			if(temperature != 9999.9 && temperature > 0 && temperature < 140)
			{
				context.write(new FloatWritable(temperature),new Text(year));
			
			}
		}
		}catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		System.out.println("Hello error is here"+value.toString()+columns);
		}
		
	}

}
