package temperature;

import java.io.IOException;
import org.apache.hadoop.fs.FileSystem;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapred.lib.TotalOrderPartitioner;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.partition.InputSampler;



import org.apache.hadoop.io.FloatWritable;


public class SortTemperature {
//@SuppressWarnings({"unchecked","rawtypes"})
	public static int main(String[] args) {
		int exitcode=0;
		// TODO Auto-generated method stub
		try{
			Configuration sort = new Configuration();
			
			//Define input and output path for the partitioner
			Path mapInputpath = new Path(args[0]);
			Path outputStage = new Path(args[1]+"_Staging");
			
			//Partitioner path
			Path partitionPath = new Path(args[1]+"-Partition.lst");
			
			//Reduce Output path
			Path outputOrder = new Path(args[1]);
			
			Job samplejob = Job.getInstance(sort,"Weather_Sampler");
			samplejob.setJarByClass(SortTemperature.class);
			samplejob.setMapperClass(TempMapper.class);
			
			//Set number of reduce task to 0
			samplejob.setNumReduceTasks(0);
			
			samplejob.setOutputKeyClass(FloatWritable.class);
			samplejob.setOutputValueClass(Text.class);
			
			TextInputFormat.setInputPaths(samplejob, mapInputpath);
			
			
			samplejob.setOutputFormatClass(SequenceFileOutputFormat.class);
			SequenceFileOutputFormat.setOutputPath(samplejob, outputStage);
			
			exitcode = samplejob.waitForCompletion(true) ? 0 : 1;
			if(exitcode!=0){return exitcode;}
			
			//setup reduce job now
			Job reducejob = Job.getInstance(sort,"Reduce_Job");
			reducejob.setJarByClass(SortTemperature.class);
			reducejob.setMapperClass(Mapper.class);
			reducejob.setReducerClass(TempReducer.class);
			
			reducejob.setNumReduceTasks(8);
			
			reducejob.setPartitionerClass(TotalOrderPartitioner.class);
			
			//generate the partition file from map-job output only
			TotalOrderPartitioner.setPartitionFile(reducejob.getConfiguration(), partitionPath);
			
			reducejob.setOutputKeyClass(FloatWritable.class);
			reducejob.setOutputValueClass(Text.class);
			
			//set input for previous jobs output
			reducejob.setInputFormatClass(SequenceFileInputFormat.class);
			SequenceFileInputFormat.setInputPaths(reducejob, outputStage);
			
			//set output path 
			TextOutputFormat.setOutputPath(reducejob, outputOrder);
			
			//reducejob.getConfiguration().set("mapred.textoutputformat.seperator", "");
			InputSampler.writePartitionFile(reducejob, new InputSampler.RandomSampler<FloatWritable,Text>(0.5, 15000 ,10));
			
			exitcode = reducejob.waitForCompletion(true)?0:1;
			
			//cleanup the temp files
			FileSystem.get(new Configuration()).delete(partitionPath,false);
			FileSystem.get(new Configuration()).delete(outputStage,true);
		
			
		}catch(IOException | ClassNotFoundException | InterruptedException ex)
		{
			ex.printStackTrace();
		}
		return exitcode;
	}

}
